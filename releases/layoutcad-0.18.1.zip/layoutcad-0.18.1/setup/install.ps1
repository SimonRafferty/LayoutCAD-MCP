# Installs layoutcad (started by "Install layoutcad.bat"). It works with ANY AI app that can use local MCP tools.
#  1. unpacks the tool (it brings its own Python) to %LOCALAPPDATA%\layoutcad\app - always, whatever AI you use
#  2. registers it with the AI apps it finds on this PC (each one's settings backed up first; anything else in
#     them is left as it is): Claude Desktop, Claude Code, Cursor, Windsurf, VS Code, LM Studio
#  3. writes "layoutcad settings for other AI apps.txt" beside the installer: the command any other app needs
param([switch]$Quiet)
$ErrorActionPreference = 'Stop'

function Say($text, $colour = 'Gray') { Write-Host $text -ForegroundColor $colour }
$utf8 = New-Object System.Text.UTF8Encoding $false
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'

function Read-Json($path) {
    if (Test-Path $path) {
        $raw = Get-Content $path -Raw
        if ($raw -and $raw.Trim()) { return ($raw | ConvertFrom-Json) }
    }
    return (New-Object psobject)
}

function Set-Server($path, $key, $entry) {
    # add/replace <key>.layoutcad in a JSON settings file (created if missing), backing it up first
    if (Test-Path $path) { Copy-Item $path ($path -replace '\.json$', ".backup-$stamp.json") }
    $j = Read-Json $path
    if (-not $j.PSObject.Properties[$key]) { $j | Add-Member -NotePropertyName $key -NotePropertyValue (New-Object psobject) }
    $j.$key | Add-Member -NotePropertyName layoutcad -NotePropertyValue $entry -Force
    New-Item -ItemType Directory -Force (Split-Path $path) | Out-Null
    [System.IO.File]::WriteAllText($path, ($j | ConvertTo-Json -Depth 50), $utf8)
}

try {
    $here = Split-Path -Parent $MyInvocation.MyCommand.Path
    $mcpb = Get-ChildItem $here -Filter 'layoutcad-*-standalone.mcpb' | Sort-Object Name | Select-Object -Last 1
    if (-not $mcpb) { throw "The file layoutcad-...-standalone.mcpb is missing from the 'setup' folder. Unzip the whole package first (right-click the zip > Extract All)." }
    $ver = $mcpb.BaseName -replace '^layoutcad-', '' -replace '-standalone$', ''
    Say ""
    Say "Installing layoutcad $ver" 'Cyan'
    Say "------------------------" 'Cyan'
    if (-not (Test-Path 'Registry::HKEY_CLASSES_ROOT\SldWorks.Application')) {
        Say "Note: SolidWorks doesn't seem to be installed on this PC. layoutcad will install, but it needs SolidWorks to build models." 'Yellow'
    }

    # 1. the tool itself - in one fixed place, so an app set up by hand keeps working after an update
    $root = Join-Path $env:LOCALAPPDATA 'layoutcad'
    $dest = Join-Path $root 'app'
    Say "Unpacking to $dest ..."
    if (Test-Path $dest) {
        try { Remove-Item $dest -Recurse -Force }
        catch { throw "The old copy is in use. Close your AI apps (Claude, Cursor, VS Code...) and run the installer again." }
    }
    Get-ChildItem $root -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'app' } |
        ForEach-Object { Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }   # older installs
    New-Item -ItemType Directory -Force $dest | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($mcpb.FullName, $dest)
    Set-Content (Join-Path $dest 'VERSION.txt') $ver
    $py = Join-Path $dest 'python\python.exe'
    $main = Join-Path $dest 'server\main.py'
    $pyver = & $py -S -c "import sys; print(sys.version.split()[0])"
    if ($LASTEXITCODE -ne 0) { throw "The bundled Python didn't start." }
    Say "  installed (with its own Python $pyver)" 'Green'

    # 2. the AI apps on this PC
    $std = [pscustomobject]@{ command = $py; args = @('-S', $main) }
    $found = @()
    Say ""
    Say "Looking for AI apps to connect it to ..."
    # Claude Desktop: settings in %APPDATA%\Claude, or (some Microsoft Store installs) inside the app's package folder
    $claudeDirs = @(Join-Path $env:APPDATA 'Claude')
    $claudeDirs += Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Packages') -Directory -Filter 'Claude_*' -ErrorAction SilentlyContinue |
        ForEach-Object { Join-Path $_.FullName 'LocalCache\Roaming\Claude' }
    $claudeApp = (Get-AppxPackage -Name 'Claude*' -ErrorAction SilentlyContinue) -or
                 (Test-Path (Join-Path $env:LOCALAPPDATA 'AnthropicClaude')) -or
                 (Test-Path (Join-Path $env:LOCALAPPDATA 'Programs\Claude'))
    $wrote = $false
    foreach ($d in $claudeDirs) {
        if (Test-Path $d) { Set-Server (Join-Path $d 'claude_desktop_config.json') 'mcpServers' $std; $wrote = $true }
    }
    if ($claudeApp -and -not $wrote) {      # installed but never opened: write where it will look
        Set-Server (Join-Path $env:APPDATA 'Claude\claude_desktop_config.json') 'mcpServers' $std; $wrote = $true
    }
    if ($wrote) { $found += 'Claude Desktop' }
    # Claude Code (command line)
    if (Get-Command claude -ErrorAction SilentlyContinue) {
        # native commands: their error output mustn't stop the script (Windows PowerShell 5.1 treats it as an error)
        $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
        & claude mcp remove layoutcad --scope user 2>&1 | Out-Null
        & claude mcp add layoutcad --scope user -- $py -S $main 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) { $found += 'Claude Code' }
        $ErrorActionPreference = $eap
    }
    # Cursor, Windsurf, LM Studio ("mcpServers"), VS Code ("servers")
    $apps = @(
        @{ name = 'Cursor';    dir = Join-Path $env:USERPROFILE '.cursor';             file = 'mcp.json';        key = 'mcpServers' },
        @{ name = 'Windsurf';  dir = Join-Path $env:USERPROFILE '.codeium\windsurf';   file = 'mcp_config.json'; key = 'mcpServers' },
        @{ name = 'LM Studio'; dir = Join-Path $env:USERPROFILE '.lmstudio';           file = 'mcp.json';        key = 'mcpServers' },
        @{ name = 'VS Code';   dir = Join-Path $env:APPDATA 'Code\User';               file = 'mcp.json';        key = 'servers' })
    foreach ($a in $apps) {
        if (Test-Path $a.dir) {
            $e = if ($a.key -eq 'servers') { [pscustomobject]@{ type = 'stdio'; command = $py; args = @('-S', $main) } } else { $std }
            Set-Server (Join-Path $a.dir $a.file) $a.key $e
            $found += $a.name
        }
    }
    if ($found) { Say ("  connected to: " + ($found -join ', ')) 'Green' }
    else { Say "  none found - that's fine: see 'layoutcad settings for other AI apps.txt'" 'Yellow' }

    # 3. for any other AI app: the settings to copy in
    $json = (@{ mcpServers = @{ layoutcad = @{ command = $py; args = @('-S', $main) } } } | ConvertTo-Json -Depth 10)
    $txt = @"
layoutcad $ver - settings for AI apps that use MCP tools
=========================================================

layoutcad is an MCP tool server ("local", "stdio" type). To use it from an AI app the installer didn't set up,
add a new MCP server in that app's settings with:

  Command:    $py
  Arguments:  -S "$main"

Most apps take this as JSON in their MCP settings file:

$json

(VS Code uses "servers" instead of "mcpServers" and adds  "type": "stdio".)
The app must run on this PC: AI apps in a web browser can't use local tools.
"@
    $txtPath = Join-Path (Split-Path $here) 'layoutcad settings for other AI apps.txt'
    [System.IO.File]::WriteAllText($txtPath, $txt, $utf8)
    Copy-Item $txtPath (Join-Path $dest 'settings for other AI apps.txt')

    Say ""
    Say "layoutcad $ver is installed." 'Green'
    Say "Restart your AI app so it picks layoutcad up (for Claude Desktop: right-click its icon by the clock > Quit, then start it again)."
    Say "Then start SolidWorks and ask your AI e.g. 'Use layoutcad to start a new project'."
    Say "Other AI apps: see 'layoutcad settings for other AI apps.txt' in this folder."
}
catch {
    Say ""
    Say "Installation didn't finish:" 'Red'
    Say "  $($_.Exception.Message)" 'Red'
    exit 1
}

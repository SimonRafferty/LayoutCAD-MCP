# Removes layoutcad (started by "Uninstall layoutcad.bat"): its entry in every AI app's settings it was added to
# (each backed up first) and its program folder. Your projects - workbooks, SolidWorks files - are not touched.
param([switch]$Quiet)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding $false
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'

function Remove-Server($path, $key) {
    if (-not (Test-Path $path)) { return $false }
    $raw = Get-Content $path -Raw
    if (-not ($raw -and $raw.Trim())) { return $false }
    $j = $raw | ConvertFrom-Json
    if (-not ($j.PSObject.Properties[$key] -and $j.$key.PSObject.Properties['layoutcad'])) { return $false }
    Copy-Item $path ($path -replace '\.json$', ".backup-$stamp.json")
    $j.$key.PSObject.Properties.Remove('layoutcad')
    [System.IO.File]::WriteAllText($path, ($j | ConvertTo-Json -Depth 50), $utf8)
    return $true
}

try {
    $files = @(@{ p = Join-Path $env:APPDATA 'Claude\claude_desktop_config.json'; k = 'mcpServers' })
    $files += Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Packages') -Directory -Filter 'Claude_*' -ErrorAction SilentlyContinue |
        ForEach-Object { @{ p = Join-Path $_.FullName 'LocalCache\Roaming\Claude\claude_desktop_config.json'; k = 'mcpServers' } }
    $files += @{ p = Join-Path $env:USERPROFILE '.cursor\mcp.json'; k = 'mcpServers' },
              @{ p = Join-Path $env:USERPROFILE '.codeium\windsurf\mcp_config.json'; k = 'mcpServers' },
              @{ p = Join-Path $env:USERPROFILE '.lmstudio\mcp.json'; k = 'mcpServers' },
              @{ p = Join-Path $env:APPDATA 'Code\User\mcp.json'; k = 'servers' }
    foreach ($f in $files) {
        if (Remove-Server $f.p $f.k) { Write-Host "Removed layoutcad from $($f.p) (a backup was kept)." }
    }
    if (Get-Command claude -ErrorAction SilentlyContinue) {
        $ErrorActionPreference = 'Continue'
        & claude mcp remove layoutcad --scope user 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) { Write-Host "Removed layoutcad from Claude Code." }
        $ErrorActionPreference = 'Stop'
    }
    $dir = Join-Path $env:LOCALAPPDATA 'layoutcad'
    if (Test-Path $dir) {
        try { Remove-Item $dir -Recurse -Force; Write-Host "Removed $dir" }
        catch { throw "layoutcad is in use. Close your AI apps and run the uninstaller again." }
    }
    Write-Host ""
    Write-Host "layoutcad is uninstalled. Restart your AI app. Your projects were not touched." -ForegroundColor Green
}
catch {
    Write-Host "Uninstall didn't finish: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

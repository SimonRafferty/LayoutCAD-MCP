@echo off
title Uninstall layoutcad
rem Double-click to remove layoutcad from Claude Desktop. Your projects are not touched.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\uninstall.ps1"
echo.
pause

@echo off
title Install layoutcad
rem Double-click to install layoutcad for Claude Desktop. The work is done by setup\install.ps1.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\install.ps1"
echo.
pause
